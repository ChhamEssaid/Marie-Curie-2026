ACTUALIZACIÓN STRAT-TRACE — 2 septiembre 2026

Cambio conceptual principal
---------------------------
La propuesta ya no se formula como un estudio genérico de cómo cambia la meteorología o el STE.
La pregunta práctica es:

¿Una misma cantidad de material estratosférico tendría hoy un destino atmosférico diferente al de hace varias décadas?

Se cuantifican cuatro respuestas:
1. transporte descendente,
2. concentración en superficie,
3. supervivencia durante el descenso,
4. eliminación por deposición húmeda y seca.

Nuevas métricas centrales
-------------------------
- Surface penetration = C_PASSIVE,surface / C_source
- Surface survival = C_AEROSOL,surface / C_PASSIVE,surface
- Removal efficiency = wet/dry deposition normalizada por fuente y/o burden

Referencias añadidas para reforzar este enfoque
------------------------------------------------
- Liu et al. (2001), DOI 10.1029/2000JD900839 — 7Be/210Pb, transporte, concentración superficial y wet deposition.
- Skerlak et al. (2019), DOI 10.5194/acp-19-6535-2019 — trazador estratosférico idealizado llegando a superficie.
- Kremenchutskii (2022), DOI 10.1016/j.chemosphere.2022.135908 — scavenging de 7Be dependiente de precipitación.

El Excel contiene 33 artículos, conclusiones, relevancia para superficie/removal y prioridad para la propuesta.
